package com.jetbrains.kmmktor2

import com.github.aakira.napier.DebugAntilog
import com.github.aakira.napier.Napier
import io.ktor.client.*
import io.ktor.client.engine.*
import io.ktor.client.engine.ios.*
import io.ktor.client.features.logging.*
import platform.Foundation.NSBundle
import platform.Foundation.NSData
import platform.Foundation.NSMutableURLRequest
import platform.Foundation.dataWithContentsOfFile
import platform.UIKit.UIDevice

actual class Platform actual constructor() {
    actual val platform: String = UIDevice.currentDevice.systemName() + " " + UIDevice.currentDevice.systemVersion
}

actual fun httpClient(config: HttpClientConfig<*>.() -> Unit) = HttpClient(Ios) {
    config(this)
    Logger.DEFAULT.log(" HTTPClient: The httpClient func Invoked")
    engine {
        configureRequest {
            setAllowsCellularAccess(true)
        }
        val ulrString = "gitcdn.link"
        val builder =
            SSLPinner.Builder()
                .add(ulrString, "sha256/YpZ10xrINW5ZpScCFt2ct+yARpBefvOwXKNAFQBfwa0=")
                .add(ulrString, "sha256/FEzVOUp4dF3gI0ZVPRJhFbSJVXR+uQmMH65xhs1glH4=")
                .add(ulrString, "sha256/Y9mvm0exBk1JoQ57f9Vm28jKo5lFm/woKcVxrYxu80o=")
        builder.isCertificatePinning = false
        handleChallenge(builder.build())
    }
}

actual fun initLogger() {
    Napier.base(DebugAntilog())
}